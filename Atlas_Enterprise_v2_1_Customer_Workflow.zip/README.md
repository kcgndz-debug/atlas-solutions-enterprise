# ATLAS Enterprise V2.1 — Customer Workflow

New estimate customer workflow:
- Choose Existing Customer or New Customer.
- Existing customers load from the company workspace.
- New customers can be entered directly inside the estimate.
- Save customer to ATLAS is checked by default.
- When checked, the new customer is saved to the customer database and used on the estimate.
- When unchecked, the customer is used only for that estimate.
- Contact, email, phone, billing address, job address, tax-exempt status, and notes are supported.

Deployment:
1. Unzip the package.
2. Upload every file to the GitHub repository root.
3. Replace existing files and commit to main.
4. Wait for Netlify to publish.
5. Open the app with ?v=2.1.0 once to refresh the cache.
